package com.example.jokeapp;

public class Joke {
 int ID;
 String Type,Setup,PunchLine;

    public Joke(int ID, String type, String setup, String punchLine) {
        this.ID = ID;
        Type = type;
        Setup = setup;
        PunchLine = punchLine;
    }

    public int getID() {
        return ID;
    }

    public String getType() {
        return Type;
    }

    public String getSetup() {
        return Setup;
    }

    public String getPunchLine() {
        return PunchLine;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setType(String type) {
        Type = type;
    }

    public void setSetup(String setup) {
        Setup = setup;
    }

    public void setPunchLine(String punchLine) {
        PunchLine = punchLine;
    }
}
