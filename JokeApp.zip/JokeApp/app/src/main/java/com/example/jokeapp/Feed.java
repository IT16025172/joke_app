package com.example.jokeapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Feed extends AppCompatActivity {
    RequestQueue queue;
    String url ="https://official-joke-api.appspot.com/jokes/random";
    String url1 ="https://official-joke-api.appspot.com/jokes/programming/random";
    TextView jokeid,joketype,jokesetup,jokepunchline;
   Button btngetjoke;
EditText filtertxt;

    String URL = "http://www.mocky.io/v2/597c41390f0000d002f4dbd1";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed);
        jokeid=findViewById(R.id.textView5);
        joketype=findViewById(R.id.textView6);
        jokesetup=findViewById(R.id.textView7);
        jokepunchline=findViewById(R.id.textView8);
        btngetjoke=findViewById(R.id.button8);
        filtertxt=findViewById(R.id.editTextTextPersonName3);
        queue=Volley.newRequestQueue(this);
        getjoke();
        //joke.setText("um joke");
        btngetjoke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mfilter=filtertxt.getText().toString().trim();
                if (mfilter.equals("All")) {
                    getjoke();
                }
                else {
                    getjokebytype(mfilter);
                }
            }
        });
    }

    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),Welcome.class));
        finish();
    }
    //Joke mjoke=new Joke();
    public void getjoke(){
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        int ID=0;
                        String type="";
                        String setup="";
                        String punchline="";
                        try {
                            ID=response.getInt("id");
                            type=response.getString("type");
                            setup=response.getString("setup");
                            punchline=response.getString("punchline");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Joke mjoke=new Joke(ID,type,setup,punchline);
                        jokeid.setText("Joke Id Is: " + mjoke.getID());
                        joketype.setText("Joke Type Is: " + mjoke.getType());
                        jokesetup.setText("Joke Setup Is: " + mjoke.getSetup());
                        jokepunchline.setText("Joke Punchline Is: " + mjoke.getPunchLine());


                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error

                    }
                });

        queue.add(jsonObjectRequest);



    }
    public void getjokebytype(String f){
       JsonArrayRequest jsonArrayRequest= new JsonArrayRequest(Request.Method.GET, "https://official-joke-api.appspot.com/jokes/"+f+"/random", null,
               new Response.Listener<JSONArray>() {
                   @Override
                   public void onResponse(JSONArray response) {
                        int count=0;
                       int ID=0;
                       String type="";
                       String setup="";
                       String punchline="";
                        while (count<response.length()){
                            try {
                                JSONObject jsonObject=response.getJSONObject(count);
                                ID=jsonObject.getInt("id");
                                type=jsonObject.getString("type");
                                setup=jsonObject.getString("setup");
                                punchline=jsonObject.getString("punchline");
                                count++;

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                       Joke mjoke=new Joke(ID,type,setup,punchline);
                       jokeid.setText("Joke Id Is: " + mjoke.getID());
                       joketype.setText("Joke Type Is: " + mjoke.getType());
                       jokesetup.setText("Joke Setup Is: " + mjoke.getSetup());
                       jokepunchline.setText("Joke Punchline Is: " + mjoke.getPunchLine());
                   }
               }, new Response.ErrorListener() {
           @Override
           public void onErrorResponse(VolleyError error) {
               jokepunchline.setText(error.toString());
           }
       });
        queue.add(jsonArrayRequest);

    }
}