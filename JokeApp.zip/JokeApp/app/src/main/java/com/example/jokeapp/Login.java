package com.example.jokeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    EditText mUsername,mPass;
    Button btnlog,btnreg;
    FirebaseAuth fAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mUsername=findViewById(R.id.editTextTextEmailAddress);
        mPass=findViewById(R.id.editTextTextPassword2);
        fAuth=FirebaseAuth.getInstance();
        btnlog=findViewById(R.id.button4);
        btnreg=findViewById(R.id.button6);

        if (fAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(),Feed.class));
            finish();
        }
        btnreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Register.class));
            }
        });
        btnlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String memail=mUsername.getText().toString().trim();

                String mpass=mPass.getText().toString().trim();
                if (TextUtils.isEmpty(memail)){
                    mUsername.setError("Email is required");
                    return;
                }
                if (TextUtils.isEmpty(mpass)){
                    mPass.setError("password is required");
                    return;
                }
                if (mpass.length()<6){
                    mPass.setError("password is not strong");
                    return;
                }
                fAuth.signInWithEmailAndPassword(memail,mpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(Login.this,"user created", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),Feed.class));
                        }else{
                            Toast.makeText(Login.this,"Email Or Username Incorrect", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

    }

}